let carts= document.querySelectorAll('.add-cart');


let product=
[{
    name: 'Fitbit Watch',
    tag:"fitbit",
    price:115,
    incart:0

},
{
    name: 'Cardio Equipment',
    tag:"cardio equipment",
    price:95,
    incart:0
},
{
    name: 'MuscleBlaze Protein Powder',
    tag:"Muscle blaze protein",
    price:45,
    incart:0
},
{
    name: 'Dumbells',
    tag:"dumbbells",
    price:230,
    incart:0
},
{
    name: 'Treadmill',
    tag:"treadmill",
    price:300,
    incart:0
},
{
    name: 'Stationary Bike',
    tag:"cycling stationary bike",
    price:145,
    incart:0
},
{
    name: 'Benches and Weights',
    tag:"benches and weights",
    price:55,
    incart:0
},
{
    name: 'Aerobics Stepper',
    tag:"aerobics stepper",
    price:50,
    incart:0
},
{
    name: 'Whey Protein',
    tag:"myprotein",
    price:40,
    incart:0

}
]

for(let i=0; i<carts.length ;i++){
    carts[i].addEventListener('click',()=>{
        cartNumbers(product[i]);
        totalCost(product[i])
    })
}

function onloadcart(){
    let productNumbers=localStorage.getItem('cartNumbers');

    if(productNumbers){
        document.querySelector('.cart span').textContent=productNumbers;
    }
}

function cartNumbers(product){
    // console.log("the product is ",product);
     let productNumbers=localStorage.getItem('cartNumbers');
    

     productNumbers=parseInt(productNumbers);

     if(productNumbers){
         localStorage.setItem('cartNumbers',productNumbers+1);
         document.querySelector('.cart span').textContent=productNumbers+1;
     }
     else{
        localStorage.setItem('cartNumbers',1);
        document.querySelector('.cart span').textContent=1;
     }
     setItems(product);

    }

    function setItems(product){
        let cartItems=localStorage.getItem('productsincart');

        cartItems=JSON.parse(cartItems)
        // console.log("my cart items are ",cartItems);


        if(cartItems!=null){

        	if(cartItems[product.tag]==undefined){
        		cartItems={
        			...cartItems,
        			[product.tag]:product
        		}
        	}

        	cartItems[product.tag].incart = cartItems[product.tag].incart+1;
        }

        else{
        	product.incart=1;

		 cartItems={
    		[product.tag]:product
     		}

        }
        
        localStorage.setItem("productsincart",JSON.stringify(cartItems));
    }

 	function totalCost(product){
 		// console.log("price is",product.price);

        // localStorage.setItem("totalCost",product.price);

 		let cartCost=localStorage.getItem('totalCost');
 		
 		console.log("my cart cost is ",cartCost);
 		console.log(typeof cartCost);

        if(cartCost!=null){
        	cartCost=parseInt(cartCost);
        	localStorage.setItem("totalCost",cartCost+product.price);
        }
        else{
 		localStorage.setItem("totalCost",product.price);
 		}
 	}

var els = document.getElementsByClassName('remove');

for (var i = 0; i < els.length; i++) {
  els[i].addEventListener('click', function () {
    this.remove();
  });
}



function displayCart(){
	let cartItems=localStorage.getItem("productsincart");
	cartItems =JSON.parse(cartItems);
	// console.log(cartItems);
 	let productContainer=document.querySelector(".products");
  let cartCost=localStorage.getItem('totalCost');

  	if(cartItems && productContainer){
  			// console.log("Running");
  			productContainer.innerHTML='';
  			Object.values(cartItems).map(item=>{
  				productContainer.innerHTML+=`
  				<div class="product stt">
  				  
  					<img class="im" src="./Media/${item.tag}.jpg">
  					<span>${item.name}</span>
  				</div>
  				<div class="price stt">$ ${item.price}</div>
  				
  				<div class="quantity stt">
                
                <span style="margin:0px 5px;"> &nbsp&nbsp ${item.incart}  </span>
                
  				</div>

          <div class="total stt">$ ${item.incart*item.price}.00</div>


  				`
  			});


        productContainer.innerHTML+=`
          <div class="basketTotalContainer">
             <h4 class="basketTotalTitle stt">Basket Total</h4>
             <h4 class="basketTotal stt">$${cartCost}.00</h4>
        `



  	}

}


    onloadcart();
    displayCart()









